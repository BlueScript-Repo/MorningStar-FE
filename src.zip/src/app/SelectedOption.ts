export class SelectedOption
{
    public key:string = '';
    public value:string = '';

}